/*
 * Refresh Mudanza (extensión): el panel que sale dentro de la página al tocar el ícono. Los mismos pasos que el
 * programa de Windows: qué se trae, cómo (Automático o Enseñarle) y la vista previa con un campo de Refresh por
 * columna. Además, lo propio de una web: pasar de página solo («Siguiente») y bajar hasta el final.
 * Todo corre en el navegador de la persona: no se manda nada a ningún servidor.
 */
(function () {
  "use strict";
  if (window.__mudanza) {
    window.__mudanza.alternar();
    return;
  }
  const N = window.MudanzaNucleo;
  const MODOS = N.armarModos(window.__mudanzaCampos);
  const URL_IMPORTAR = "https://app.refresh.do/panel/ajustes/importar";
  const A_LA_VISTA = 50;
  const MAX_PAGINAS = 300;

  const estado = {
    modo: MODOS[0],
    tabla: null,
    mapa: [],
    candidatas: [],
    elegida: 0,
    patron: null,
    primerEjemplo: null,
    /** nada | ejemplo1 | ejemplo2 | columnas | siguiente */
    senalando: "nada",
    botonSiguiente: null,
    sumar: false,
    corriendo: false,
    parar: false,
  };

  /* ------------------------------- Pantalla ------------------------------ */

  const raiz = document.createElement("div");
  raiz.id = "refresh-mudanza";
  raiz.style.cssText = "all:initial;position:fixed;z-index:2147483647;right:16px;bottom:16px;";
  const sombra = raiz.attachShadow({ mode: "open" });
  sombra.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; font-family: "Segoe UI", system-ui, Arial, sans-serif; }
      .caja { width: min(560px, calc(100vw - 32px)); max-height: min(640px, calc(100vh - 32px)); display: flex; flex-direction: column;
        background: #f4efe6; color: #16130f; border: 2px solid #16130f; box-shadow: 6px 6px 0 #16130f; font-size: 13px; }
      .cabeza { background: #16130f; color: #f4efe6; padding: 8px 12px; display: flex; align-items: center; gap: 8px; cursor: default; }
      .cabeza b { color: #ff5a1f; font-size: 15px; letter-spacing: .04em; flex: 1; }
      .cabeza button { background: none; border: 0; color: #f4efe6; font-size: 18px; cursor: pointer; padding: 0 4px; line-height: 1; }
      .cuerpo { padding: 10px 12px; overflow: auto; display: flex; flex-direction: column; gap: 8px; }
      .fila { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
      .rotulo { font: 700 11px Consolas, monospace; text-transform: uppercase; color: #6b645a; width: 100%; }
      button.b, select { border: 2px solid #16130f; background: #fff; color: #16130f; font-weight: 700; font-size: 13px; padding: 5px 9px; cursor: pointer; }
      button.b.marca, button.b.activo { background: #ff5a1f; }
      button.b:disabled { opacity: .5; cursor: default; }
      select { font-weight: 600; max-width: 100%; }
      .estado { background: #fff; border: 1px solid #16130f; padding: 8px 10px; font-weight: 700; line-height: 1.4; }
      .vista { overflow: auto; max-height: 240px; border: 1px solid #16130f; background: #fff; }
      table { border-collapse: collapse; font-size: 12px; width: max-content; min-width: 100%; }
      th { background: #16130f; color: #f4efe6; padding: 4px 6px; text-align: left; position: sticky; top: 0; vertical-align: top; font-weight: 600; }
      th select { border: 0; background: #16130f; color: #ff5a1f; font-size: 12px; padding: 0; font-weight: 700; display: block; max-width: 150px; }
      th select.nada { color: #9a948a; }
      th span { display: block; color: #cfc8bb; font-size: 11px; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      td { padding: 3px 6px; border-top: 1px solid #e3ddd0; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      td.nada { color: #9a948a; }
      .resumen { color: #6b645a; flex: 1; min-width: 120px; }
      .falta { color: #b42318; font-weight: 700; }
      label.c { display: inline-flex; gap: 5px; align-items: center; font-weight: 600; cursor: pointer; }
      a { color: #16130f; font-weight: 700; }
      .oculto { display: none !important; }
    </style>
    <div class="caja" role="dialog" aria-label="Refresh Mudanza">
      <div class="cabeza"><b>REFRESH MUDANZA</b><button id="achicar" title="Encoger" aria-label="Encoger">–</button><button id="cerrar" title="Cerrar" aria-label="Cerrar">×</button></div>
      <div class="cuerpo" id="cuerpo">
        <div class="fila"><span class="rotulo">1 · ¿Qué vas a traer?</span><span id="modos" class="fila"></span></div>
        <div class="fila"><span class="rotulo">2 · ¿Cómo?</span>
          <button class="b marca" id="auto" title="Busca sola la tabla o la lista más grande de la página">Automático</button>
          <button class="b" id="ensenar" title="Tú señalas un dato en dos filas y Mudanza saca toda la lista">Enseñarle</button>
          <select id="candidatas" class="oculto" title="Otras listas de esta página"></select>
        </div>
        <div class="fila" id="masFilas"><span class="rotulo">3 · ¿Hay más páginas?</span>
          <button class="b" id="siguiente" title="Señalas una vez el botón «Siguiente» y Mudanza pasa todas las páginas sola">Pasar las páginas sola…</button>
          <button class="b" id="bajar" title="Para listas que cargan más al bajar">Bajar hasta el final</button>
          <label class="c" title="Si cada página abre una dirección nueva: abre Mudanza en cada una y las filas se van sumando"><input type="checkbox" id="sumar"> Sumar a lo que ya tengo</label>
        </div>
        <div class="estado" id="estado" aria-live="polite"></div>
        <div class="vista oculto" id="vista"></div>
        <div class="fila">
          <button class="b marca" id="guardar">Descargar para Refresh</button>
          <button class="b" id="limpiar">Limpiar</button>
          <span class="resumen" id="resumen"></span>
        </div>
      </div>
    </div>`;
  const $ = (id) => sombra.getElementById(id);

  // El marco naranja que rodea lo que se va a tomar.
  const marco = document.createElement("div");
  marco.style.cssText = "all:initial;position:fixed;z-index:2147483646;pointer-events:none;border:3px solid #ff5a1f;box-shadow:0 0 0 1px #16130f;display:none;";

  function decir(textoEstado) {
    $("estado").textContent = textoEstado;
  }

  function faltan() {
    if (estado.modo.libre) return [];
    return estado.modo.campos.filter((c) => c.requerida && !estado.mapa.some((m) => m && m.clave === c.clave)).map((c) => c.titulo);
  }

  function pintar() {
    const modos = $("modos");
    modos.textContent = "";
    for (const m of MODOS) {
      const b = document.createElement("button");
      b.className = "b" + (m === estado.modo ? " activo" : "");
      b.textContent = m.nombre;
      b.title = m.descripcion;
      b.onclick = () => {
        estado.modo = m;
        if (estado.tabla) estado.mapa = N.adivinar(m, estado.tabla.titulos, estado.tabla.filas);
        pintar();
        guardarAvance();
      };
      modos.append(b);
    }
    $("ensenar").textContent = ["ejemplo1", "ejemplo2", "columnas"].includes(estado.senalando) ? "Terminar" : "Enseñarle";
    $("ensenar").classList.toggle("activo", ["ejemplo1", "ejemplo2", "columnas"].includes(estado.senalando));
    $("siguiente").textContent = estado.corriendo ? "Parar" : "Pasar las páginas sola…";
    $("siguiente").classList.toggle("activo", estado.corriendo || estado.senalando === "siguiente");
    $("sumar").checked = estado.sumar;
    const sel = $("candidatas");
    sel.classList.toggle("oculto", estado.candidatas.length < 2);
    sel.textContent = "";
    estado.candidatas.forEach((c, i) => sel.add(new Option(`${c.tabla.origen}: ${c.tabla.filas.length} filas × ${c.tabla.titulos.length} columnas`, i, false, i === estado.elegida)));

    const vista = $("vista");
    const t = estado.tabla;
    vista.classList.toggle("oculto", !t || !t.filas.length);
    vista.textContent = "";
    if (!t || !t.filas.length) {
      $("resumen").textContent = "";
      return;
    }
    const tabla = document.createElement("table");
    const cabeza = tabla.createTHead().insertRow();
    t.titulos.forEach((titulo, i) => {
      const th = document.createElement("th");
      const propio = titulo || `Columna ${i + 1}`;
      if (estado.modo.libre) th.textContent = propio;
      else {
        const s = document.createElement("select");
        s.setAttribute("aria-label", `Campo de la columna ${propio}`);
        s.add(new Option("(no se trae)", ""));
        for (const c of estado.modo.campos) s.add(new Option(c.titulo + (c.requerida ? " *" : ""), c.clave));
        s.value = estado.mapa[i]?.clave ?? "";
        s.className = estado.mapa[i] ? "" : "nada";
        s.onchange = () => {
          const campo = estado.modo.campos.find((c) => c.clave === s.value) ?? null;
          // Un campo va en una sola columna: se le quita a la que lo tenía.
          if (campo) estado.mapa = estado.mapa.map((m) => (m && m.clave === campo.clave ? null : m));
          estado.mapa[i] = campo;
          pintar();
          guardarAvance();
        };
        const nombre = document.createElement("span");
        nombre.textContent = propio;
        th.append(s, nombre);
      }
      cabeza.append(th);
    });
    const cuerpo = tabla.createTBody();
    for (const f of t.filas.slice(0, A_LA_VISTA)) {
      const tr = cuerpo.insertRow();
      f.forEach((v, i) => {
        const td = tr.insertCell();
        td.textContent = v;
        td.title = v;
        if (!estado.modo.libre && !estado.mapa[i]) td.className = "nada";
      });
    }
    vista.append(tabla);
    const f = faltan();
    const r = $("resumen");
    r.textContent = `${t.filas.length} filas` + (t.filas.length > A_LA_VISTA ? ` (se ven ${A_LA_VISTA})` : "") + (f.length ? ` · Falta: ${f.join(", ")}` : "");
    r.classList.toggle("falta", f.length > 0);
  }

  /* ------------------------------ Lo guardado ---------------------------- */

  /** Lo que se lleva sacado queda guardado en el navegador, para seguir sumando en otra página del mismo sitio. */
  function guardarAvance() {
    try {
      const t = estado.tabla;
      chrome.storage.local.set({
        mudanza: t && t.filas.length ? { modo: estado.modo.clave, titulos: t.titulos, filas: t.filas, mapa: estado.mapa.map((m) => m?.clave ?? null), sumar: estado.sumar, sitio: location.hostname } : null,
      });
    } catch {
      /* fuera de la extensión (pruebas): no hay dónde guardar */
    }
  }

  function cargarAvance() {
    try {
      chrome.storage.local.get("mudanza", ({ mudanza: g }) => {
        if (!g || !g.sumar || g.sitio !== location.hostname || estado.tabla) return;
        estado.modo = MODOS.find((m) => m.clave === g.modo) ?? MODOS[0];
        estado.tabla = { titulos: g.titulos, filas: g.filas, origen: "Lo que ya tenías" };
        estado.mapa = g.mapa.map((k) => estado.modo.campos.find((c) => c.clave === k) ?? null);
        estado.sumar = true;
        pintar();
        decir(`Sigues con las ${g.filas.length} filas que ya tenías. Pulsa «Automático» para sumar las de esta página.`);
      });
    } catch {
      /* igual que arriba */
    }
  }

  /** Recibe una captura: la suma a lo que hay (mismas columnas y «Sumar» marcado) o la pone en su lugar. */
  function recibir(nueva, sumarSiempre) {
    nueva = N.limpia(nueva);
    const t = estado.tabla;
    if ((estado.sumar || sumarSiempre) && t && t.filas.length && t.titulos.length === nueva.titulos.length) {
      const n = N.sumar(t, nueva);
      decir(n ? `Se sumaron ${n} filas. Van ${t.filas.length}.` : `Esas filas ya estaban. Van ${t.filas.length}.`);
    } else {
      estado.tabla = nueva;
      estado.mapa = N.adivinar(estado.modo, nueva.titulos, nueva.filas);
      decir(
        nueva.filas.length
          ? `Listo: ${nueva.filas.length} filas. Revisa arriba de cada columna a qué campo de Refresh va (se cambia ahí mismo) y descarga.`
          : "No salió ninguna fila. Prueba «Enseñarle».",
      );
    }
    pintar();
    guardarAvance();
  }

  /* ------------------------------- Automático ---------------------------- */

  function automatico() {
    terminarDeSenalar();
    estado.patron = null;
    estado.candidatas = N.buscarTablas(document);
    estado.elegida = 0;
    if (!estado.candidatas.length) {
      pintar();
      decir("No encontré ninguna tabla ni lista en esta página. Deja la lista a la vista y vuelve a intentarlo, o usa «Enseñarle».");
      return;
    }
    recibir(estado.candidatas[0].tabla, false);
    if (estado.candidatas.length > 1) decir($("estado").textContent + ` Encontré ${estado.candidatas.length} listas: si no es esta, elige otra al lado de «Enseñarle».`);
  }

  /** Lo que se ve ahora de la lista con la que se está trabajando (la señalada o la automática). */
  function leerActual() {
    if (estado.patron) return estado.patron.contenedor.isConnected ? N.leerPatron(estado.patron) : null;
    const c = estado.candidatas[estado.elegida];
    if (!c) return null;
    const otraVez = N.releer(c);
    if (otraVez) return otraVez;
    // La página cambió la lista por otra nueva (pasa al cambiar de página): la más parecida a la de antes.
    const nuevas = N.buscarTablas(document);
    const igual = nuevas.find((n) => n.esTabla === c.esTabla && n.tabla.titulos.length === c.tabla.titulos.length);
    if (igual) estado.candidatas[estado.elegida] = igual;
    return igual?.tabla ?? null;
  }

  /* -------------------------------- Señalar ------------------------------ */

  function alMover(e) {
    const el = e.composedPath()[0];
    if (!(el instanceof Element) || e.composedPath().includes(raiz)) {
      marco.style.display = "none";
      return;
    }
    const r = el.getBoundingClientRect();
    Object.assign(marco.style, { display: "block", left: r.left - 3 + "px", top: r.top - 3 + "px", width: r.width + 6 + "px", height: r.height + 6 + "px" });
  }

  function alTocar(e) {
    const el = e.composedPath()[0];
    if (!(el instanceof Element) || e.composedPath().includes(raiz)) return;
    // El clic es para Mudanza: no debe abrir el enlace ni marcar la fila de la página.
    e.preventDefault();
    e.stopImmediatePropagation();
    if (e.type !== "click") return;
    try {
      senalado(el);
    } catch (error) {
      decir(error.message);
    }
  }

  function alTeclear(e) {
    if (e.key === "Escape") {
      terminarDeSenalar();
      decir("Cancelado.");
    }
  }

  const EVENTOS = ["click", "mousedown", "mouseup", "pointerdown", "pointerup"];

  function empezarASenalar(que) {
    terminarDeSenalar();
    estado.senalando = que;
    document.addEventListener("mousemove", alMover, true);
    for (const ev of EVENTOS) document.addEventListener(ev, alTocar, true);
    document.addEventListener("keydown", alTeclear, true);
    pintar();
  }

  function terminarDeSenalar() {
    if (estado.senalando === "nada") return;
    estado.senalando = "nada";
    document.removeEventListener("mousemove", alMover, true);
    for (const ev of EVENTOS) document.removeEventListener(ev, alTocar, true);
    document.removeEventListener("keydown", alTeclear, true);
    marco.style.display = "none";
    pintar();
  }

  function senalado(el) {
    if (estado.senalando === "ejemplo1") {
      estado.primerEjemplo = el;
      estado.senalando = "ejemplo2";
      decir(`2 de 2 · Tomé «${N.texto(el).slice(0, 40)}». Ahora haz clic en el mismo dato de OTRA fila (la de abajo).`);
    } else if (estado.senalando === "ejemplo2") {
      estado.patron = N.aprender(estado.primerEjemplo, el);
      estado.candidatas = [];
      estado.senalando = "columnas";
      recibir(N.leerPatron(estado.patron), false);
      decir(`Entendido: ${estado.tabla.filas.length} filas. Para otra columna, haz clic en otro dato de una fila (teléfono, precio…). Al acabar, «Terminar».`);
    } else if (estado.senalando === "columnas") {
      const r = N.agregarColumna(estado.patron, el);
      if (r === "fuera") return decir("Ese dato está fuera de la lista que señalaste. Haz clic en uno de la misma fila, o pulsa «Terminar».");
      if (r === "repetida") return decir("Ese dato ya está en una columna. Haz clic en otro, o pulsa «Terminar».");
      const antes = estado.mapa;
      estado.tabla = null;
      recibir(N.leerPatron(estado.patron), false);
      // Lo que la persona ya había elegido en las columnas de antes no se pierde.
      if (estado.tabla.titulos.length === antes.length + 1) estado.mapa = [...antes, estado.mapa[antes.length]].map((m, i, todos) => (m && todos.findIndex((x) => x && x.clave === m.clave) !== i ? null : m));
      pintar();
      decir(`Columna sumada: van ${estado.patron.columnas.length}. Haz clic en otro dato, o pulsa «Terminar».`);
    } else if (estado.senalando === "siguiente") {
      estado.botonSiguiente = el.closest("a, button, [role=button], li, input") ?? el;
      terminarDeSenalar();
      pasarPaginas();
    }
  }

  /* --------------------------- Más páginas y bajar ----------------------- */

  const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

  /** Espera a que la lista cambie (hasta 8 s): devuelve la tabla nueva o null si se quedó igual. */
  async function esperarCambio(antes) {
    for (let i = 0; i < 40; i++) {
      await esperar(200);
      const ahora = leerActual();
      if (ahora) {
        const limpia = N.limpia(ahora);
        if (limpia.filas.length && limpia.filas.map(N.llave).join("\n") !== antes) return limpia;
      }
    }
    return null;
  }

  function apagado(boton) {
    return !boton || !boton.isConnected || boton.disabled || boton.getAttribute("aria-disabled") === "true" || /\b(disabled|inactivo|deshabilitado)\b/i.test(boton.className);
  }

  /** Si la página volvió a dibujar el botón, lo busca otra vez por lo que dice. */
  function botonVivo() {
    const b = estado.botonSiguiente;
    if (b?.isConnected) return b;
    const dice = N.texto(b) || b?.getAttribute("aria-label") || b?.title || "";
    const iguales = [...document.querySelectorAll(b?.tagName ?? "button")].filter((x) => !raiz.contains(x) && (N.texto(x) || x.getAttribute("aria-label") || x.title || "") === dice && x.className === b.className);
    return (estado.botonSiguiente = iguales[0] ?? null);
  }

  async function pasarPaginas() {
    if (!estado.tabla?.filas.length || !leerActual()) return decir("Primero saca la lista de esta página con «Automático» o «Enseñarle».");
    estado.corriendo = true;
    estado.parar = false;
    pintar();
    let paginas = 1;
    let motivo = "no hay más páginas";
    while (paginas < MAX_PAGINAS && !estado.parar) {
      const boton = botonVivo();
      if (apagado(boton)) break;
      const antes = N.limpia(leerActual() ?? { titulos: [], filas: [] }).filas.map(N.llave).join("\n");
      boton.click();
      const nueva = await esperarCambio(antes);
      if (!nueva) {
        motivo = "la lista no cambió al pasar de página";
        break;
      }
      const sumadas = N.sumar(estado.tabla, nueva);
      paginas++;
      decir(`Página ${paginas}: van ${estado.tabla.filas.length} filas…`);
      pintar();
      if (!sumadas) {
        motivo = "la página siguiente no trajo filas nuevas";
        break;
      }
    }
    estado.corriendo = false;
    if (estado.parar) motivo = "lo paraste";
    else if (paginas >= MAX_PAGINAS) motivo = `se llegó al tope de ${MAX_PAGINAS} páginas`;
    pintar();
    guardarAvance();
    decir(`Terminé: ${estado.tabla.filas.length} filas de ${paginas} páginas (${motivo}).`);
  }

  async function bajarHastaElFinal() {
    if (!estado.tabla?.filas.length || !leerActual()) return decir("Primero saca la lista de esta página con «Automático» o «Enseñarle».");
    estado.corriendo = true;
    estado.parar = false;
    // Lo que se puede bajar: la página y, si la lista tiene su propia barra, sus cajas.
    const cajas = [document.scrollingElement];
    const base = estado.patron?.contenedor ?? estado.candidatas[estado.elegida]?.elemento;
    for (let a = base; a && a !== document.body; a = a.parentElement) if (a.scrollHeight > a.clientHeight + 20 && /auto|scroll/.test(getComputedStyle(a).overflowY)) cajas.push(a);
    let sinNuevas = 0;
    for (let vuelta = 0; vuelta < 2000 && sinNuevas < 4 && !estado.parar; vuelta++) {
      for (const c of cajas) c.scrollTop = c.scrollHeight;
      await esperar(700);
      const ahora = leerActual();
      const n = ahora ? N.sumar(estado.tabla, N.limpia(ahora)) : 0;
      sinNuevas = n ? 0 : sinNuevas + 1;
      decir(`Bajando… van ${estado.tabla.filas.length} filas.`);
    }
    estado.corriendo = false;
    pintar();
    guardarAvance();
    decir(`Terminé de bajar: ${estado.tabla.filas.length} filas.`);
  }

  /* -------------------------------- Descargar ---------------------------- */

  function descargar() {
    const t = estado.tabla;
    if (!t?.filas.length) return decir("Todavía no hay nada que descargar. Empieza por «Automático».");
    if (!estado.modo.libre && !estado.mapa.some(Boolean)) return decir("Ninguna columna tiene campo. Elige arriba de cada columna qué es.");
    const archivos = N.archivosCsv(t, estado.modo, estado.mapa);
    archivos.forEach((contenido, i) => {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([contenido], { type: "text/csv;charset=utf-8" }));
      a.download = `refresh-${estado.modo.clave}${archivos.length > 1 ? `-parte-${i + 1}` : ""}.csv`;
      sombra.append(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 10_000);
    });
    const f = faltan();
    const e = $("estado");
    e.textContent = archivos.length > 1 ? `Descargados ${archivos.length} archivos (Refresh recibe hasta ${N.FILAS_POR_ARCHIVO} filas por archivo: súbelos uno por uno). ` : "Descargado. ";
    if (f.length) e.append(`Ojo: falta ${f.join(", ")}; complétalo en Excel antes de subirlo. `);
    if (!estado.modo.libre) {
      const tipo = { clientes: "Clientes", articulos: "Artículos", equipos: "Equipos" }[estado.modo.plantilla];
      e.append(`Ahora, en Refresh: Ajustes → Conexiones → Importar desde Excel, «${tipo}» y «Subir archivo». `);
      const enlace = document.createElement("a");
      enlace.href = URL_IMPORTAR;
      enlace.target = "_blank";
      enlace.rel = "noopener";
      enlace.textContent = "Abrir Refresh";
      e.append(enlace);
    }
  }

  /* --------------------------------- Botones ------------------------------ */

  $("auto").onclick = automatico;
  $("ensenar").onclick = () => {
    if (["ejemplo1", "ejemplo2", "columnas"].includes(estado.senalando)) {
      terminarDeSenalar();
      if (estado.tabla?.filas.length) decir(`Listo: ${estado.tabla.filas.length} filas. Revisa los campos y descarga, o sigue con las demás páginas.`);
      return;
    }
    empezarASenalar("ejemplo1");
    decir("1 de 2 · Haz clic en un dato de la primera fila de la lista (por ejemplo, el nombre). Esc cancela.");
  };
  $("candidatas").onchange = (e) => {
    estado.elegida = Number(e.target.value);
    estado.tabla = null;
    recibir(estado.candidatas[estado.elegida].tabla, false);
  };
  $("siguiente").onclick = () => {
    if (estado.corriendo) return void (estado.parar = true);
    if (!estado.tabla?.filas.length) return decir("Primero saca la lista de esta página con «Automático» o «Enseñarle».");
    empezarASenalar("siguiente");
    decir("Haz clic una vez en el botón que pasa a la página siguiente (el «Siguiente» o la flecha ›). Yo sigo sola. Esc cancela.");
  };
  $("bajar").onclick = () => (estado.corriendo ? (estado.parar = true) : bajarHastaElFinal());
  $("sumar").onchange = (e) => {
    estado.sumar = e.target.checked;
    guardarAvance();
  };
  $("guardar").onclick = descargar;
  $("limpiar").onclick = () => {
    terminarDeSenalar();
    Object.assign(estado, { tabla: null, mapa: [], candidatas: [], patron: null });
    pintar();
    guardarAvance();
    decir("Listo para empezar de nuevo.");
  };
  $("achicar").onclick = () => $("cuerpo").classList.toggle("oculto");
  $("cerrar").onclick = () => window.__mudanza.alternar();

  window.__mudanza = {
    estado,
    alternar() {
      terminarDeSenalar();
      estado.parar = true;
      const visible = raiz.style.display !== "none";
      raiz.style.display = visible ? "none" : "";
    },
  };

  document.documentElement.append(marco, raiz);
  pintar();
  decir("Deja a la vista la lista que quieres traer (clientes, artículos…) y pulsa «Automático».");
  cargarAvance();
})();
