/*
 * Refresh Mudanza (extensión): al tocar el ícono, pone el panel en la pestaña que se está viendo. Solo esa pestaña y
 * solo cuando la persona lo toca (permiso «activeTab»): la extensión no lee ninguna página por su cuenta.
 */
chrome.action.onClicked.addListener(async (pestana) => {
  try {
    const campos = await (await fetch(chrome.runtime.getURL("campos.json"))).json();
    await chrome.scripting.executeScript({
      target: { tabId: pestana.id },
      func: (c) => {
        window.__mudanzaCampos = c;
      },
      args: [campos],
    });
    await chrome.scripting.executeScript({ target: { tabId: pestana.id }, files: ["nucleo.js", "panel.js"] });
    chrome.action.setBadgeText({ tabId: pestana.id, text: "" });
  } catch {
    // Las páginas del propio navegador (chrome://, la tienda de extensiones) no dejan entrar a ninguna extensión.
    chrome.action.setBadgeBackgroundColor({ color: "#b42318" });
    chrome.action.setBadgeText({ tabId: pestana.id, text: "!" });
    chrome.action.setTitle({ tabId: pestana.id, title: "Refresh Mudanza no puede entrar a esta página" });
  }
});
