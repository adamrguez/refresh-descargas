/*
 * Prueba la extensión en un navegador de verdad (Playwright), contra pagina.html: el modo automático, «Enseñarle»
 * con dos clics, pasar las páginas sola y el CSV que se descarga.   node mudanza/extension/pruebas/probar.mjs
 */
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { chromium } from "playwright";

const aqui = dirname(fileURLToPath(import.meta.url));
const ext = join(aqui, "..");
const exigir = (ok, mensaje) => {
  if (!ok) throw new Error(mensaje);
  console.log("  ✓", mensaje);
};

const navegador = await chromium.launch();
const pagina = await navegador.newPage({ acceptDownloads: true });
pagina.on("pageerror", (e) => console.log("ERROR EN LA PÁGINA:", e.message));
await pagina.goto(pathToFileURL(join(aqui, "pagina.html")).href);

// Lo mismo que hace fondo.js al tocar el ícono.
const campos = JSON.parse(readFileSync(join(ext, "campos.json"), "utf8"));
await pagina.evaluate((c) => (window.__mudanzaCampos = c), campos);
await pagina.addScriptTag({ path: join(ext, "nucleo.js") });
await pagina.addScriptTag({ path: join(ext, "panel.js") });

const panel = pagina.locator("#refresh-mudanza");
const estado = () => pagina.evaluate(() => {
  const e = window.__mudanza.estado;
  return { filas: e.tabla?.filas.length ?? 0, titulos: e.tabla?.titulos ?? [], mapa: e.mapa.map((m) => m?.clave ?? null), primera: e.tabla?.filas[0] ?? [], candidatas: e.candidatas.length };
});

console.log("Automático (clientes)");
await panel.getByRole("button", { name: "Automático" }).click();
let e = await estado();
exigir(e.filas === 10, `saca las 10 filas de la página (${e.filas})`);
// La quinta columna («Editar») no es de ningún campo: se queda sin traer.
exigir(e.mapa.join() === "nombre,telefono,documento,email,", `reconoce los campos y deja fuera la columna de «Editar» (${e.mapa.join()})`);
exigir(e.primera[0] === "Juan Pérez 1", `la primera fila es la primera (${e.primera[0]})`);
exigir(e.candidatas === 2, `encuentra la tabla y la lista de tarjetas (${e.candidatas})`);

console.log("Pasar las páginas sola");
await panel.getByRole("button", { name: "Pasar las páginas sola…" }).click();
await pagina.getByRole("button", { name: "Siguiente ›" }).click();
await pagina.waitForFunction(() => window.__mudanza.estado.corriendo === false && window.__mudanza.estado.tabla.filas.length >= 25, null, { timeout: 30_000 });
e = await estado();
exigir(e.filas === 25, `junta las 25 filas de las 3 páginas (${e.filas})`);
exigir((await pagina.locator("#pagina").textContent()) === "Página 3 de 3", "el clic en «Siguiente» no se quedó pegado: llegó a la última");

console.log("Descargar para Refresh");
const [descarga] = await Promise.all([pagina.waitForEvent("download"), panel.getByRole("button", { name: "Descargar para Refresh" }).click()]);
const csv = readFileSync(await descarga.path(), "utf8");
exigir(descarga.suggestedFilename() === "refresh-clientes.csv", `el archivo se llama ${descarga.suggestedFilename()}`);
exigir(csv.split("\r\n")[0] === "﻿Nombre,Teléfono,Cédula o RNC,Correo", `títulos de la plantilla de Refresh (${csv.split("\r\n")[0]})`);
exigir(csv.trim().split("\r\n").length === 26, "25 filas y la de títulos");

console.log("Automático (inventario, en tarjetas)");
await panel.getByRole("button", { name: "Limpiar" }).click();
await panel.getByRole("button", { name: "Inventario" }).click();
await panel.getByRole("button", { name: "Automático" }).click();
await panel.locator("#candidatas").selectOption("1");
e = await estado();
exigir(e.filas === 8 && e.titulos.length === 4, `la lista de tarjetas sale con 8 filas y 4 columnas (${e.filas} × ${e.titulos.length})`);
exigir(e.primera.join("|") === "P-100|Pantalla modelo 1|0|RD$ 1,500.00", `cada dato en su columna (${e.primera.join("|")})`);

console.log("Enseñarle (dos ejemplos y una columna más)");
await panel.getByRole("button", { name: "Limpiar" }).click();
await panel.getByRole("button", { name: "Enseñarle" }).click();
await pagina.locator(".tarjeta .desc").nth(0).click();
await pagina.locator(".tarjeta .desc").nth(1).click();
e = await estado();
exigir(e.filas === 8 && e.titulos.length === 1, `con dos clics saca la columna entera (${e.filas} filas)`);
await pagina.locator(".tarjeta .precio").nth(0).click();
await pagina.locator(".tarjeta .cod").nth(3).click();
e = await estado();
exigir(e.titulos.length === 3 && e.primera.join("|") === "Pantalla modelo 1|RD$ 1,500.00|P-100", `cada clic suma una columna (${e.primera.join("|")})`);
await pagina.locator("nav a").first().click();
exigir((await panel.locator("#estado").textContent()).includes("fuera de la lista"), "un dato de fuera de la lista no entra");
await panel.getByRole("button", { name: "Terminar" }).click();
exigir(pagina.url().endsWith("pagina.html"), "los clics de señalar no abrieron ningún enlace");

await navegador.close();
console.log("EXTENSIÓN OK");
