/*
 * Refresh Mudanza (extensión): lo que no es pantalla. Reconocer a qué campo de Refresh va cada columna (igual que
 * el programa de Windows, mudanza/windows/src/Campos.cs), encontrar las tablas y listas de una página, aprender
 * una lista con dos ejemplos y armar el CSV. Sin dependencias; corre en la página (como script de contenido) y en
 * Node (tests/mudanza.test.ts).
 */
(function (global) {
  "use strict";

  /* ------------------------------ Campos ------------------------------ */

  /** Arma los modos con sus campos a partir de campos.json. */
  function armarModos(datos) {
    return datos.modos.map((m) => {
      if (!m.plantilla) return { ...m, libre: true, campos: [] };
      const todos = datos.plantillas[m.plantilla];
      const delModo = m.campos.map((k) => todos.find((c) => c.clave === k));
      return { ...m, libre: false, campos: [...delModo, ...todos.filter((c) => !m.campos.includes(c.clave))] };
    });
  }

  /** Sin tildes, en minúsculas y sin signos: «Teléfono:» y «TELEFONO» son lo mismo. */
  function normalizar(s) {
    return String(s ?? "")
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim();
  }

  function puntosPorTitulo(campo, titulo) {
    const t = normalizar(titulo);
    if (!t) return 0;
    const nombres = [campo.titulo, ...(campo.otros ?? [])].map(normalizar);
    if (nombres.includes(t)) return 100;
    for (const n of nombres) {
      if (n.length >= 4 && ` ${t} `.includes(` ${n} `)) return 70;
      // Una abreviatura («Tel.», «Desc») es el comienzo de la primera palabra, no la palabra entera («Stock» no es «Stock mínimo»).
      if (t.length >= 3 && !t.includes(" ") && n.startsWith(t) && n.split(" ")[0].length > t.length) return 60;
    }
    return 0;
  }

  const digitos = (v) => (v.match(/\d/g) ?? []).length;
  const FECHA = /^\d{1,4}[/.-]\d{1,2}[/.-]\d{1,4}(\s.+)?$/;
  const ES = {
    telefono: (v) => /^\+?[\d\s().-]{7,20}$/.test(v) && digitos(v) >= 7 && digitos(v) <= 15 && !FECHA.test(v),
    documento: (v) => (digitos(v) === 9 || digitos(v) === 11) && /^[\d\s-]+$/.test(v),
    correo: (v) => /^[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}$/.test(v),
    dinero: (v) => /^-?\s*(RD\$|US\$|\$|€)?\s*\d{1,3}([.,\s]?\d{3})*([.,]\d{1,2})?\s*$/.test(v),
    entero: (v) => /^-?\d{1,7}([.,]0+)?$/.test(v),
    fecha: (v) => FECHA.test(v),
    barras: (v) => /^\d{8,14}$/.test(v),
    codigo: (v) => /^[A-Za-z0-9][A-Za-z0-9._/-]{1,24}$/.test(v) && /\d/.test(v),
    nombre: (v) => v.length >= 3 && (v.match(/\p{L}/gu) ?? []).length >= v.length * 0.6,
    direccion: (v) => v.length >= 10 && v.includes(" ") && /\b(calle|av|avenida|no|num|esq|sector|res|km|c)\b/.test(normalizar(v)),
  };

  /** Qué parte (0 a 1) de los valores de la columna parece de ese tipo. */
  function parecido(tipo, valores) {
    const es = ES[tipo];
    const llenos = valores.map((v) => String(v ?? "").trim()).filter(Boolean).slice(0, 200);
    if (!es || !llenos.length) return 0;
    return llenos.filter(es).length / llenos.length;
  }

  /**
   * A qué campo va cada columna (null = no se trae). Manda el título; lo que queda sin dueño se decide por el
   * contenido, y solo cuando casi todos sus valores lo parecen. Un campo no se da dos veces.
   */
  function adivinar(modo, titulos, filas) {
    const n = Math.max(titulos.length, ...filas.map((f) => f.length), 0);
    const resultado = Array(n).fill(null);
    if (modo.libre) return resultado;
    const usados = new Set();
    const columna = (i) => filas.map((f) => f[i] ?? "");
    const porTitulo = [];
    for (let i = 0; i < n; i++)
      for (const c of modo.campos) {
        const p = puntosPorTitulo(c, titulos[i]);
        if (p > 0) porTitulo.push([p, i, c]);
      }
    porTitulo.sort((a, b) => b[0] - a[0]);
    for (const [, i, c] of porTitulo) {
      if (resultado[i] || usados.has(c.clave)) continue;
      resultado[i] = c;
      usados.add(c.clave);
    }
    const seguros = ["correo", "telefono", "documento", "barras", "fecha"];
    for (let i = 0; i < n; i++) {
      if (resultado[i]) continue;
      let mejor = null;
      let puntos = 0.8;
      for (const c of modo.campos) {
        if (!seguros.includes(c.tipo) || usados.has(c.clave)) continue;
        const p = parecido(c.tipo, columna(i));
        if (p > puntos) [mejor, puntos] = [c, p];
      }
      if (mejor) {
        resultado[i] = mejor;
        usados.add(mejor.clave);
      }
    }
    for (const c of modo.campos) {
      if (!c.requerida || usados.has(c.clave)) continue;
      let mejor = -1;
      let puntos = 0.7;
      for (let i = 0; i < n; i++) {
        if (resultado[i]) continue;
        const valores = columna(i);
        let p = parecido(c.tipo, valores);
        // El nombre o la descripción suele ser la columna de texto más larga.
        if (c.tipo === "nombre") p *= Math.min(1, valores.reduce((s, v) => s + String(v ?? "").length, 0) / Math.max(1, valores.length) / 12);
        if (p > puntos) [mejor, puntos] = [i, p];
      }
      if (mejor >= 0) {
        resultado[mejor] = c;
        usados.add(c.clave);
      }
    }
    return resultado;
  }

  /* ------------------------------- Tabla ------------------------------- */

  const limpiar = (s) => String(s ?? "").replace(/ /g, " ").replace(/\s+/g, " ").trim();
  const llave = (fila) => fila.map((c) => limpiar(c)).join("\u001f");

  /** Filas del mismo ancho, sin las vacías ni las columnas sin nada. */
  function limpia(tabla) {
    const n = Math.max(tabla.titulos.length, ...tabla.filas.map((f) => f.length), 0);
    const filas = tabla.filas.map((f) => Array.from({ length: n }, (_, i) => limpiar(f[i]))).filter((f) => f.some(Boolean));
    const conDatos = Array.from({ length: n }, (_, i) => i).filter((i) => filas.some((f) => f[i]));
    return {
      origen: tabla.origen ?? "",
      titulos: conDatos.map((i) => limpiar(tabla.titulos[i])),
      filas: filas.map((f) => conDatos.map((i) => f[i])),
    };
  }

  /** Suma a `base` las filas de `otra` que no tenga. Devuelve cuántas entraron. */
  function sumar(base, otra) {
    const vistas = new Set(base.filas.map(llave));
    let nuevas = 0;
    if (!base.titulos.some(Boolean)) base.titulos = [...otra.titulos];
    for (const f of otra.filas)
      if (!vistas.has(llave(f))) {
        vistas.add(llave(f));
        base.filas.push(f);
        nuevas++;
      }
    return nuevas;
  }

  function celdaCsv(v) {
    v = String(v ?? "");
    // Una celda que empieza con = + - @ la toma Excel como fórmula: va con un apóstrofo, salvo que sea un número.
    if (/^[=+\-@]/.test(v) && !/^[+-]?[\d\s.,()-]+$/.test(v)) v = "'" + v;
    return /[",;\n\r]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
  }

  /** Lo que acepta Ajustes → Importar desde Excel de Refresh por archivo (5000 filas y 1.8 MB). */
  const FILAS_POR_ARCHIVO = 4000;

  /**
   * Los CSV (con BOM y comas: los abre Excel y los lee Refresh), partidos si pasan del límite de Refresh. Con un
   * modo de Refresh salen solo las columnas con campo, con el título de la plantilla y en su orden.
   */
  function archivosCsv(tabla, modo, mapa) {
    let titulos;
    let columnas;
    if (modo.libre) {
      columnas = tabla.titulos.map((_, i) => i);
      titulos = tabla.titulos.map((t, i) => t || `Columna ${i + 1}`);
    } else {
      columnas = [];
      titulos = [];
      for (const c of modo.campos) {
        const i = mapa.findIndex((m) => m && m.clave === c.clave);
        if (i < 0) continue;
        columnas.push(i);
        titulos.push(c.titulo);
      }
    }
    const linea = (celdas) => celdas.map(celdaCsv).join(",") + "\r\n";
    const archivos = [];
    for (let desde = 0; desde < tabla.filas.length; desde += FILAS_POR_ARCHIVO) {
      let texto = "﻿" + linea(titulos);
      for (const f of tabla.filas.slice(desde, desde + FILAS_POR_ARCHIVO)) texto += linea(columnas.map((i) => f[i] ?? ""));
      archivos.push(texto);
    }
    return archivos;
  }

  /* ------------------------------ La página ---------------------------- */

  /** Lo que dice un elemento: lo escrito en un campo, o su texto a la vista. */
  function texto(el) {
    if (!el) return "";
    if (el.matches?.("input:not([type=password]):not([type=hidden]), textarea")) return limpiar(el.value);
    if (el.matches?.("select")) return limpiar(el.selectedOptions?.[0]?.textContent);
    const campo = el.querySelector?.("input:not([type=password]):not([type=hidden]):not([type=checkbox]):not([type=radio]), textarea");
    const propio = limpiar(el.innerText ?? el.textContent);
    return propio || (campo ? limpiar(campo.value) : "");
  }

  function seVe(el) {
    if (!el.getClientRects?.().length) return false;
    const estilo = el.ownerDocument.defaultView.getComputedStyle(el);
    return estilo.visibility !== "hidden" && estilo.display !== "none";
  }

  const firma = (el) => el.tagName + "." + [...el.classList].sort().join(".");

  /** Tablas de verdad: `<table>` y las hechas con role="grid" o "table". */
  function deTablas(doc) {
    const halladas = [];
    for (const t of doc.querySelectorAll("table, [role=grid], [role=table], [role=treegrid]")) {
      if (!seVe(t)) continue;
      const esTabla = t.tagName === "TABLE";
      const filasEl = [...t.querySelectorAll(esTabla ? "tr" : "[role=row]")].filter((f) => f.closest("table, [role=grid], [role=table], [role=treegrid]") === t);
      const celdasDe = (f) => [...f.children].filter((c) => (esTabla ? /^(TD|TH)$/.test(c.tagName) : c.matches("[role=cell], [role=gridcell], [role=columnheader], [role=rowheader]")));
      let titulos = [];
      const filas = [];
      for (const f of filasEl) {
        const celdas = celdasDe(f);
        if (!celdas.length) continue;
        const sonTitulos = celdas.every((c) => c.tagName === "TH" || c.matches("[role=columnheader]")) || !!f.closest("thead");
        if (sonTitulos) {
          if (!titulos.length) titulos = celdas.map(texto);
          continue;
        }
        if (f.closest("tfoot")) continue;
        filas.push(celdas.map(texto));
      }
      if (filas.length >= 2) halladas.push({ elemento: t, tabla: limpia({ titulos, filas, origen: "Tabla" }), esTabla: true });
    }
    return halladas;
  }

  /** Las hojas con texto de una fila, cada una con su camino (etiquetas y clases) desde la fila. */
  function hojas(fila) {
    const salida = [];
    const bajar = (el, camino) => {
      for (const h of el.children) {
        if (/^(SCRIPT|STYLE|SVG|NOSCRIPT|TEMPLATE)$/i.test(h.tagName) || !seVe(h)) continue;
        const clave = camino + ">" + firma(h);
        const tieneTexto = [...h.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim()) || h.matches("input:not([type=hidden]):not([type=password]), select, textarea");
        if (tieneTexto || !h.children.length) {
          const t = texto(h);
          if (t) salida.push([clave, t]);
        } else bajar(h, clave);
      }
    };
    bajar(fila, "");
    return salida;
  }

  /** Listas hechas con bloques repetidos (tarjetas, renglones con div): 3 hijos o más con la misma forma. */
  function deRepetidos(doc, yaVistas) {
    const halladas = [];
    for (const cont of doc.body.querySelectorAll("*")) {
      if (cont.children.length < 3 || /^(TABLE|THEAD|TBODY|TR|SELECT|NAV|HEADER|FOOTER|SVG)$/i.test(cont.tagName)) continue;
      if (cont.closest("nav, [role=navigation], [role=menu], [role=menubar], [role=tablist], header, footer, #refresh-mudanza") || yaVistas.some((t) => t.contains(cont))) continue;
      const grupos = new Map();
      for (const h of cont.children) {
        const k = firma(h);
        grupos.set(k, [...(grupos.get(k) ?? []), h]);
      }
      const filasEl = [...grupos.values()].sort((a, b) => b.length - a.length)[0];
      if (filasEl.length < 3 || filasEl.length < cont.children.length * 0.6 || !seVe(cont)) continue;
      const porFila = filasEl.map(hojas);
      // Columnas: los caminos que aparecen en al menos un tercio de las filas, en el orden en que salen.
      const cuenta = new Map();
      for (const hs of porFila) for (const k of new Set(hs.map((h) => h[0]))) cuenta.set(k, (cuenta.get(k) ?? 0) + 1);
      const columnas = [...cuenta].filter(([, n]) => n >= Math.max(2, filasEl.length / 3)).map(([k]) => k);
      if (columnas.length < 2) continue;
      const filas = porFila.map((hs) => columnas.map((k) => hs.filter((h) => h[0] === k).map((h) => h[1]).join(" ")));
      halladas.push({ elemento: cont, tabla: limpia({ titulos: [], filas, origen: "Lista" }), esTabla: false });
    }
    return halladas;
  }

  /** Todas las tablas y listas de la página, la mejor primero (más filas y columnas; una tabla de verdad vale doble). */
  function buscarTablas(doc) {
    const tablas = deTablas(doc);
    const todas = [...tablas, ...deRepetidos(doc, tablas.map((t) => t.elemento))]
      .filter((c) => c.tabla.filas.length >= 2 && c.tabla.titulos.length >= 1)
      .map((c) => ({ ...c, puntos: c.tabla.filas.length * Math.min(c.tabla.titulos.length, 12) * (c.esTabla ? 2 : 1) * (c.tabla.titulos.length >= 2 ? 1 : 0.2) }))
      .sort((a, b) => b.puntos - a.puntos);
    // Una lista que está dentro de otra mejor (o que la envuelve) es la misma información: se queda la mejor.
    const sinRepetir = [];
    for (const c of todas) if (!sinRepetir.some((m) => m.elemento.contains(c.elemento) || c.elemento.contains(m.elemento))) sinRepetir.push(c);
    return sinRepetir.slice(0, 8);
  }

  /** Vuelve a leer una tabla o lista ya encontrada (después de pasar de página o de bajar). */
  function releer(candidata) {
    const doc = candidata.elemento.ownerDocument;
    if (!candidata.elemento.isConnected) return null;
    const lista = candidata.esTabla ? deTablas(doc) : deRepetidos(doc, []);
    return lista.find((c) => c.elemento === candidata.elemento)?.tabla ?? null;
  }

  /* ------------------------------ Enseñarle ---------------------------- */

  function ancestros(el) {
    const ruta = [];
    for (let a = el; a; a = a.parentElement) ruta.unshift(a);
    return ruta;
  }

  /** El camino de una fila a un dato: en cada nivel, la etiqueta, sus clases y su número entre los de su etiqueta. */
  function camino(fila, el) {
    const pasos = [];
    for (let a = el; a && a !== fila; a = a.parentElement) {
      const iguales = [...a.parentElement.children].filter((h) => h.tagName === a.tagName);
      pasos.unshift({ etiqueta: a.tagName, clases: [...a.classList], indice: iguales.indexOf(a) });
    }
    return pasos;
  }

  /** Sigue un camino en otra fila: por sus clases si señalan a uno solo; si no, por su número. */
  function seguir(fila, pasos) {
    let actual = fila;
    for (const p of pasos) {
      const iguales = [...actual.children].filter((h) => h.tagName === p.etiqueta);
      const porClase = p.clases.length ? iguales.filter((h) => p.clases.every((c) => h.classList.contains(c))) : [];
      actual = porClase.length === 1 ? porClase[0] : iguales[p.indice];
      if (!actual) return null;
    }
    return actual;
  }

  /** Con el mismo dato de dos filas distintas: donde se separan sus caminos está la lista. */
  function aprender(uno, dos) {
    const r1 = ancestros(uno);
    const r2 = ancestros(dos);
    let d = 0;
    while (d < r1.length && d < r2.length && r1[d] === r2[d]) d++;
    if (d >= r1.length || d >= r2.length) throw new Error("Señalaste el mismo dato dos veces. El segundo tiene que ser el de otra fila.");
    const contenedor = r1[d - 1];
    const comunes = [...r1[d].classList].filter((c) => r2[d].classList.contains(c));
    return { contenedor, etiquetaFila: r1[d].tagName, clasesFila: r1[d].tagName === r2[d].tagName ? comunes : [], columnas: [camino(r1[d], uno)] };
  }

  function filasDe(patron) {
    return [...patron.contenedor.children].filter((h) => h.tagName === patron.etiquetaFila && patron.clasesFila.every((c) => h.classList.contains(c)));
  }

  /** Otro dato de la misma lista: una columna más. "fuera" si no está en la lista, "repetida" si ya estaba. */
  function agregarColumna(patron, el) {
    const fila = filasDe(patron).find((f) => f.contains(el));
    if (!fila) return "fuera";
    const nuevo = camino(fila, el);
    const igual = (a, b) => a.length === b.length && a.every((p, i) => p.etiqueta === b[i].etiqueta && p.indice === b[i].indice);
    if (patron.columnas.some((c) => igual(c, nuevo))) return "repetida";
    patron.columnas.push(nuevo);
    return "nueva";
  }

  function leerPatron(patron) {
    const filas = filasDe(patron).map((f) => patron.columnas.map((c) => texto(seguir(f, c))));
    // En una tabla, el título de cada columna es el <th> de su misma posición.
    let titulos = patron.columnas.map(() => "");
    const tabla = patron.contenedor.closest?.("table");
    if (tabla && patron.etiquetaFila === "TR") {
      const ths = [...tabla.querySelectorAll("thead th, tr:first-child th")];
      titulos = patron.columnas.map((c) => (c[0]?.etiqueta === "TD" ? texto(ths[c[0].indice]) : ""));
    }
    return { titulos, filas, origen: "Lo que señalaste" };
  }

  const api = {
    armarModos, normalizar, puntosPorTitulo, parecido, adivinar, limpia, sumar, llave, archivosCsv, FILAS_POR_ARCHIVO,
    texto, buscarTablas, releer, aprender, agregarColumna, leerPatron, filasDe,
  };
  global.MudanzaNucleo = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
